package controlador;

/**
 * created by sinNombre on nov., 13/11/2021
 */
public class Controlador_datosRecibidos {

    public boolean comprobarDatos(String text, String text1, String text2, String text3) {
        // `pendiente comprobar que el email/ telefono = valido
        // o ya existe
        return true;
    }
}
