/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author sinNombre
 */
public class ProtocoloServer {
    final static String SEPARADOR = ":";
              public final static String NULLA = "NULLA";
    
    final static String ENVIAR = "ENVIAR";
    final static String LOGIN = "LOGIN";
    final static String REGISTER = "REGISTER";
    
    final static String LOGIN_OK = "LOGIN_OK";
    final static String LOGIN_NOT_OK = "LOGIN_NOT_OK";
    
    public final static String REGISTER_FORM="REGISTER_FORM";
    
}
