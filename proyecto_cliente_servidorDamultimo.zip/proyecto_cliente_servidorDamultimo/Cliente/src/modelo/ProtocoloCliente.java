/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author sinNombre
 */
public class ProtocoloCliente {
   public final static String SEPARADOR = ":";
   public final static String NULLA = "NULLA";
   
   
    
   public final static String ENVIAR = "ENVIAR";
   public final static String LOGIN = "LOGIN";
   public final static String REGISTER = "REGISTER";
    
   public final static String LOGIN_OK = "LOGIN_OK";
   public final static String LOGIN_NOT_OK = "LOGIN_NOT_OK";
   
    public final static String REGISTER_FORM="REGISTER_FORM";
    
}
